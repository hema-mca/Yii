<!--
Note that only PHP 7 and PHP 8 compatibility issues are accepted. For security issues contact maintainers privately.
-->

### What steps will reproduce the problem?

### What is the expected result?

### What do you get instead?


### Additional info

| Q                | A
| ---------------- | ---
| Yii version      | 1.1.?
| PHP version      | 7.?
| Operating system |
