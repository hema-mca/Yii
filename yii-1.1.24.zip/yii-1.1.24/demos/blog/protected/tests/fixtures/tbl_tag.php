<?php

return array(
	array(
		'name'=>'yii',
		'frequency'=>1,
	),
	array(
		'name'=>'blog',
		'frequency'=>1,
	),
);
